#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define EXIT 1
#define BOARD 5

typedef char chessPos[2];

typedef struct _chessPosArray {
    unsigned int size;
    chessPos* positions;
} chessPosArray;

////////////////////////////////

typedef struct _chessPosCell {
    chessPos position;
    struct _chessPosCell* next;
} chessPosCell;

typedef struct _chessPosList {
    chessPosCell* head;
    chessPosCell* tail;
} chessPosList;

////////////////////////////////

typedef struct _treeNode treeNode;

typedef struct _treeNodeList {
    struct _treeNodeListCell* head;
    struct _treeNodeListCell* tail;
} treeNodeList;

typedef struct _treeNode {
    chessPos position;
    treeNodeList next_possible_positions;
} treeNode;

typedef struct _treeNodeListCell {
    treeNode* node;
    struct _treeNodeListCell* next;
} treeNodeListCell;

typedef struct _pathTree {
    treeNode* root;
} pathTree;
////////////////////////////////


// main
void freeTreeHelper(treeNode* root);
void freeMatrix(int** matrix);
void isValid(chessPos userPos);
void freeTree(pathTree* tree);

// array - q1
char numToChar(int i);
bool inMatrix(int i, int j);
void CheckAllocation(void* ptr);
int findSizeKnight(int i, int j);
chessPosArray*** validKnightMoves();
chessPos* findPosKnight(int i, int j, int size);
void insertSizeAndPos(chessPosArray*** res);

// list - q2
char charToNum(char ch);
void printMatrix(int*** matrix);
void display(chessPosList* lst);
bool isEmptyList(chessPosList* lst);
void makeEmptyList(chessPosList* lst);
chessPosList* adjustList(chessPosList* lst);
int** buildChessBoardFromList(chessPosList* lst);
void insertDataToEndList(chessPosList* lst, chessPos data);
void insertNodeToEndList(chessPosList* lst, chessPosCell* tail);
chessPosCell* createNewListNode(chessPos data, chessPosCell* next);

// tree - q3
void buildPathTree(treeNode* root, bool visited[][BOARD], chessPosArray*** matrixPos);
treeNodeListCell* createNewTreeListNode(treeNode* node, treeNodeListCell* next);
void insertNodeToEndTreeList(treeNodeList* lst, treeNodeListCell* tail);
pathTree findAllPossibleKnightPaths(chessPos* startingPosition);
void insertDataToEndTreeList(treeNodeList* lst, treeNode* node);
void freeMatrixPos(chessPosArray*** matrixPos);
treeNode* createTreeNode(chessPos position);
void makeEmptyTreeList(treeNodeList* lst);

// *** - q4
chessPosList* findKnightPathCoveringAllBoardHelper(treeNode* root, bool visited[BOARD][BOARD], bool* fullMatrix, chessPosList* lst);
chessPosList* findKnightPathCoveringAllBoard(pathTree* path_tree);
void removeDataFromEndList(chessPosList* lst);
bool isFullMatrix(bool visited[BOARD][BOARD]);

void main() {
    chessPos userPos;
    userPos[0] = getchar();
    userPos[1] = getchar();
    
    if (getchar() != '\n') {
        printf("Invalid input");
        exit(1);
    }

    isValid(userPos);

    chessPosList* lst;
    pathTree tree = findAllPossibleKnightPaths(&userPos);
    lst = findKnightPathCoveringAllBoard(&tree);

    if (lst == NULL) {
        printf("No knight's tour");
    }
    else
        display(lst);

    freeTree(&tree);
    
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void isValid(chessPos userPos) {
    char lett = userPos[0];
    char dig = userPos[1];

    if ((lett >= 'A' && lett < 'A' + BOARD) && (dig >= '1' && dig < '1' + BOARD))
        return;
    else {
        printf("Invalid input");
        exit(1);
    }
}

void freeTree(pathTree* tree) {
    freeTreeHelper(tree->root);
}

void freeTreeHelper(treeNode* root) {
    
    if (root->next_possible_positions.head == NULL && root->next_possible_positions.tail == NULL) {
        free(root);
        return;
    }

    treeNodeListCell* curr = root->next_possible_positions.head;
    treeNodeListCell* tmp = curr;

    while (curr != NULL) {
        freeTreeHelper(curr->node);
        tmp = curr;
        curr = curr->next;  
        root->next_possible_positions.head = curr;
        free(tmp);
    }

    return;
}

void freeMatrix(int** matrix) {

    for (int i = 0; i < BOARD; i++) {

        free(matrix[i]);
    }
    free(matrix);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

chessPosArray*** validKnightMoves() { // create an array of all steps the knight can make from posistion on board
    int i = 0, j = 0;

    chessPosArray*** res = (chessPosArray***)malloc(BOARD * sizeof(chessPosArray**));
    CheckAllocation(&res);

    for (i = 0; i < BOARD; i++) {
        res[i] = (chessPosArray**)malloc(BOARD * sizeof(chessPosArray*));
        CheckAllocation(res[i]);

        for (j = 0; j < BOARD; j++) {
            res[i][j] = (chessPosArray*)malloc(sizeof(chessPosArray));
            CheckAllocation(res[i][j]);
        }
    }

    insertSizeAndPos(res);

    return res;
}

void insertSizeAndPos(chessPosArray*** res) {
    int i = 0, j = 0;
    int size = 0;

    for (i = 0; i < BOARD; i++)
    {
        for (j = 0; j < BOARD; j++)
        {
            size = findSizeKnight(i, j);
            (res[i][j])->size = size;
            (res[i][j])->positions = findPosKnight(i, j, size);
        }
    }
}

void CheckAllocation(void* ptr) //check the success of the malloc
{
    if (ptr == NULL) {
        exit(EXIT);
    }
}

int findSizeKnight(int i, int j) { // find how many steps the knight can do
    
    int counter = 0;

    if (inMatrix(i + 2, j + 1)) {
        counter++;
    }
    if (inMatrix(i + 1, j + 2)) {
        counter++;
    }
    if (inMatrix(i - 1, j + 2)) {
        counter++;
    }
    if (inMatrix(i - 2, j + 1)) {
        counter++;
    }
    if (inMatrix(i - 2, j - 1)) {
        counter++;
    }
    if (inMatrix(i - 1, j - 2)) {
        counter++;
    }
    if (inMatrix(i + 1, j - 2)) {
        counter++;
    }
    if (inMatrix(i + 2, j - 1)) {
        counter++;
    }

    return counter;
    

}

chessPos* findPosKnight(int i, int j, int size) { // find the places the knight can get

    int counter = 0;

    chessPos* pos = (chessPos*)malloc(size * sizeof(chessPos));

    if (inMatrix(i - 2, j + 1)) {
        pos[counter][0] = numToChar(i - 2);
        pos[counter][1] = j + 1 + 1;
        counter++;
    }
    if (inMatrix(i - 1, j + 2)) {
        pos[counter][0] = numToChar(i - 1);
        pos[counter][1] = j + 2 + 1;
        counter++;
    }
    if (inMatrix(i + 1, j + 2)) {
        pos[counter][0] = numToChar(i + 1);
        pos[counter][1] = j + 2 + 1;
        counter++;
    }
    if (inMatrix(i + 2, j + 1)) {
        pos[counter][0] = numToChar(i + 2);
        pos[counter][1] = j + 1 + 1;
        counter++;
    }
    if (inMatrix(i + 2, j - 1)) {
        pos[counter][0] = numToChar(i + 2);
        pos[counter][1] = j - 1 + 1;
        counter++;
    }
    if (inMatrix(i + 1, j - 2)) {
        pos[counter][0] = numToChar(i + 1);
        pos[counter][1] = j - 2 + 1;
        counter++;
    }
    if (inMatrix(i - 1, j - 2)) {
        pos[counter][0] = numToChar(i - 1);
        pos[counter][1] = j - 2 + 1;
        counter++;
    }
    if (inMatrix(i - 2, j - 1)) {
        pos[counter][0] = numToChar(i - 2);
        pos[counter][1] = j - 1 + 1;
        counter++;
    }

    return pos;
}

bool inMatrix(int i, int j) { // check if the move is on the board
    if ((i >= 0 && i <= BOARD-1) && (j >= 0 && j <= BOARD - 1))
        return true;
    else
        return false;
}

char numToChar(int i) {

    return 'A' + i;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void display(chessPosList* lst) { // adjust the list and build matrix from the list information
    chessPosList* res;
    res = adjustList(lst);
    int** board = NULL;
    board = buildChessBoardFromList(res);
    printMatrix(&board);
    freeMatrix(board);
}

void printMatrix(int*** matrix) { // print the matrix
    int p = 0, k = 0;
    int i = 0;
    
    printf("   ");
    
    for (i = 0; i < BOARD; i++)
    {
        if (1 + k <= 8) {
            printf("%d  ", 1 + k);
            k++;
        }
        else if (1 + k == 9) {
            printf("%d ", 1 + k);
            k++;
        }
        else if (1 + k >= 10) {
            printf("%2d ", 1 + k);
            k++;
        }
    }
    
    printf("\n");
    k = 0;
    
    for (i = 0; i < BOARD; i++)
    {
        printf("%c", 'A' + k);
        k++;
        for (int j = 0; j < BOARD; j++)
        {
            printf("|");
            printf("%2d", (*matrix)[i][j]);
        }
        
        printf("|");
        printf("\n");
    }
}

int** buildChessBoardFromList(chessPosList* lst) { // build matrix by the lisr information
    
    int** board = (int**)malloc(BOARD * sizeof(int*));
    for (int i = 0; i < BOARD; i++) {
        board[i] = (int*)malloc(BOARD * sizeof(int));
        
        for (int j = 0; j < BOARD; j++) {
            board[i][j] = 0; 
        }
    }

    int index = 1;
    chessPosCell* curr = lst->head;
    int i = 0, j = 0;

    while (curr != NULL) {
        i = charToNum(curr->position[0]);
        j = (curr->position[1]) - 1;  ///// deleted

        board[i][j] = index;
        index++;
        curr = curr->next;
    }

    return board;
}

chessPosList* adjustList(chessPosList* lst) { // remove all position that showed twice at the list
    chessPosList* res = (chessPosList*)malloc(sizeof(chessPosList));
    chessPosCell* currOrigin = lst->head;
    makeEmptyList(res);
    
    insertDataToEndList(res, lst->head->position);
    chessPosCell* currNew = res->head;
    bool exist = false;

    while (currOrigin != NULL) {
        exist = false;
        currNew = res->head;

        while (currNew != NULL) {

            if (currOrigin->position[0] == currNew->position[0] && currOrigin->position[1] == currNew->position[1]) {
                exist = true;
                break;
            }
            currNew = currNew->next;
        }
        if(exist == false)
            insertDataToEndList(res, currOrigin->position);
        
        currOrigin = currOrigin->next;
    }

    return res;
}

void insertDataToEndList(chessPosList* lst, chessPos data) // insert data to the end of a list
{
    chessPosCell* newTail;
    newTail = createNewListNode(data, NULL);
    insertNodeToEndList(lst, newTail);
}

chessPosCell* createNewListNode(chessPos data, chessPosCell* next) // creat new node 
{
    chessPosCell* res = NULL;
    res = (chessPosCell*)malloc(sizeof(chessPosCell));
    CheckAllocation(res);

    res->position[0] = data[0];
    res->position[1] = data[1];

    res->next = next;

    return res;
}

void insertNodeToEndList(chessPosList* lst, chessPosCell* tail) // insert node to end list
{
    if (isEmptyList(lst) == true) {
        lst->head = lst->tail = tail;
    }
    else {
        lst->tail->next = tail;
        lst->tail = tail;
    }
    tail->next = NULL;
}

bool isEmptyList(chessPosList* lst) // check if the list is empty
{
    if (lst->head == NULL)
        return true;
    else
        return false;
}

void makeEmptyList(chessPosList* lst) // make list empty by NULL
{
    lst->head = NULL;
    lst->tail = NULL;
}

char charToNum(char ch) {

    return ch - 'A';
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

pathTree findAllPossibleKnightPaths(chessPos* startingPosition) { // build tree with all possible positions
    pathTree tree;

    int i = startingPosition[0][0] - 'A'; 
    int j = startingPosition[0][1] - '1';
    startingPosition[0][1] = startingPosition[0][1] - '0';

    treeNode* root = createTreeNode(*startingPosition);

    bool visited[BOARD][BOARD] = { false }; // matrix of all steps that we already been
    visited[i][j] = true;

    chessPosArray*** matrixPos = validKnightMoves(); // all possible positions by function from task 1

    buildPathTree(root, visited, matrixPos); // rec function that build the tree
    
    freeMatrixPos(matrixPos);

    tree.root = root;

    return tree;
}

void freeMatrixPos(chessPosArray*** matrixPos) {
    for (int i = 0; i < BOARD; i++) {

        free(matrixPos[i]);
    }
    free(matrixPos);
}

void buildPathTree(treeNode* root, bool visited[][BOARD], chessPosArray*** matrixPos) {
    int i = root->position[0] - 'A';
    int j = root->position[1] - 1;
    bool check = true;

    for (int k = 0; k < matrixPos[i][j]->size; k++) {           // 
        int newI = matrixPos[i][j]->positions[k][0] - 'A';      //
        int newJ = matrixPos[i][j]->positions[k][1] - 1;        // check if we have been at all possible positions
        if (visited[newI][newJ] == false) {                     //
            check = false;                                      //
            break;
        }
    }
    if (check == true) {
        root = createTreeNode(root->position);
        return;
    }

    for (int k = 0; k < matrixPos[i][j]->size; k++) {
        int newI = matrixPos[i][j]->positions[k][0] - 'A';
        int newJ = matrixPos[i][j]->positions[k][1] - 1;

        if (visited[newI][newJ] == false) { // if we havent been at that position
            visited[newI][newJ] = true;
            
            treeNode* child = createTreeNode(matrixPos[i][j]->positions[k]);
            insertDataToEndTreeList(&(root->next_possible_positions), child);

            buildPathTree(child, visited, matrixPos);

            visited[newI][newJ] = false;
        }
    }
}

treeNode* createTreeNode(chessPos position) { // create tree node
    treeNode* node = (treeNode*)malloc(sizeof(treeNode));
    CheckAllocation(node);

    node->position[0] = position[0];
    node->position[1] = position[1];
    node->next_possible_positions.head = node->next_possible_positions.tail = NULL;

    return node;
}

void makeEmptyTreeList(treeNodeList* lst) { // make empty list
    lst->head = NULL;
    lst->tail = NULL;
}

void insertDataToEndTreeList(treeNodeList* lst, treeNode* node) // insert data to the end of a list
{
    treeNodeListCell* newTail;
    newTail = createNewTreeListNode(node, NULL);
    insertNodeToEndTreeList(lst, newTail);
}

treeNodeListCell* createNewTreeListNode(treeNode* node, treeNodeListCell* next) // creat new tree list node 
{
    treeNodeListCell* res;
    res = (treeNodeListCell*)malloc(sizeof(treeNodeListCell));
    CheckAllocation(res);

    res->node = node;
    res->next = next;

    return res;
}

void insertNodeToEndTreeList(treeNodeList* lst, treeNodeListCell* tail) { // insert the node to the end of the list
    if (lst->head == NULL) {
        lst->head = lst->tail = tail;
    }
    else {
        lst->tail->next = tail;
        lst->tail = tail;
    }
    tail->next = NULL;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

chessPosList* findKnightPathCoveringAllBoard(pathTree* path_tree) {
    bool fullMatrix = false;
    chessPosList* lst = (chessPosList*)malloc(sizeof(chessPosList));
    makeEmptyList(lst);

    bool visited[BOARD][BOARD] = { false }; // matrix of all steps that we already been

    insertDataToEndList(lst, path_tree->root->position);
    lst = findKnightPathCoveringAllBoardHelper(path_tree->root, visited, &fullMatrix, lst);
    return lst;
}

chessPosList* findKnightPathCoveringAllBoardHelper(treeNode* root, bool visited[BOARD][BOARD], bool* fullMatrix, chessPosList* lst) {

    int i = root->position[0] - 'A';
    int j = root->position[1] - 1;
    visited[i][j] = true;

    if (isFullMatrix(visited) == true) {
        insertDataToEndList(lst, root->position);
        *fullMatrix = true;
        return lst;
    }

    if (*fullMatrix == true)
        return lst;

    treeNodeListCell* curr = root->next_possible_positions.head;

    while(curr != NULL) {
        int newI = curr->node->position[0] - 'A';
        int newJ = curr->node->position[1] - 1;

        if (visited[newI][newJ] == false) { // if we havent been at that position
            insertDataToEndList(lst, curr->node->position);
            findKnightPathCoveringAllBoardHelper(curr->node, visited, fullMatrix, lst);
            
            if (!*fullMatrix)
                removeDataFromEndList(lst);
            else
                return lst;
        }

        curr = curr->next;
    }

    visited[i][j] = false;
    return NULL;
}

void removeDataFromEndList(chessPosList* lst) {

    chessPosCell* curr = lst->head;
    if (lst->head->next == NULL) {
        makeEmptyList(lst);
    }

    while (curr->next != lst->tail) {
        curr = curr->next;
    }

    chessPosCell* temp = curr->next;
    lst->tail = curr;
    curr->next = NULL;
    free(temp);

}

bool isFullMatrix(bool visited[BOARD][BOARD]) {
    for (int i = 0; i < BOARD; i++) {
        for (int j = 0; j < BOARD; j++) {
            if (!visited[i][j]) {
                return false;
            }
        }
    }
    return true;
}

 