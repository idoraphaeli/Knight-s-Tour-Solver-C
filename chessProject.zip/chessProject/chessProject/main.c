#include "chessProject.h"
#include <stdio.h>

void main() {
    chessPos userPos;
    printf("Enter the knight's starting position using a capital letter and a number (like A3):\n");
    userPos[0] = getchar();
    userPos[1] = getchar();

    if (getchar() != '\n') {
        printf("Invalid input");
        exit(1);
    }

    isValid(userPos);

    chessPosList* lst;
    pathTree tree = findAllPossibleKnightPaths(&userPos);
    lst = findKnightPathCoveringAllBoard(&tree);

    if (lst == NULL) {
        printf("No knight's tour");
    }
    else
        display(lst);

    freeTree(&tree);

}