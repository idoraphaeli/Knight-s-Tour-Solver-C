#pragma once
#ifndef chessProject_h
#define chessProject_h

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define EXIT 1
#define BOARD 5

typedef char chessPos[2];

typedef struct _chessPosArray {
    unsigned int size;
    chessPos* positions;
} chessPosArray;

////////////////////////////////

typedef struct _chessPosCell {
    chessPos position;
    struct _chessPosCell* next;
} chessPosCell;

typedef struct _chessPosList {
    chessPosCell* head;
    chessPosCell* tail;
} chessPosList;

////////////////////////////////

typedef struct _treeNode treeNode;

typedef struct _treeNodeList {
    struct _treeNodeListCell* head;
    struct _treeNodeListCell* tail;
} treeNodeList;

typedef struct _treeNode {
    chessPos position;
    treeNodeList next_possible_positions;
} treeNode;

typedef struct _treeNodeListCell {
    treeNode* node;
    struct _treeNodeListCell* next;
} treeNodeListCell;

typedef struct _pathTree {
    treeNode* root;
} pathTree;

////////////////////////////////


// main
void freeTreeHelper(treeNode* root);
void freeMatrix(int** matrix);
void isValid(chessPos userPos);
void freeTree(pathTree* tree);

// array - q1
char numToChar(int i);
bool inMatrix(int i, int j);
void CheckAllocation(void* ptr);
int findSizeKnight(int i, int j);
chessPosArray*** validKnightMoves();
chessPos* findPosKnight(int i, int j, int size);
void insertSizeAndPos(chessPosArray*** res);

// list - q2
char charToNum(char ch);
void printMatrix(int*** matrix);
void display(chessPosList* lst);
bool isEmptyList(chessPosList* lst);
void makeEmptyList(chessPosList* lst);
chessPosList* adjustList(chessPosList* lst);
int** buildChessBoardFromList(chessPosList* lst);
void insertDataToEndList(chessPosList* lst, chessPos data);
void insertNodeToEndList(chessPosList* lst, chessPosCell* tail);
chessPosCell* createNewListNode(chessPos data, chessPosCell* next);

// tree - q3
void buildPathTree(treeNode* root, bool visited[][BOARD], chessPosArray*** matrixPos);
treeNodeListCell* createNewTreeListNode(treeNode* node, treeNodeListCell* next);
void insertNodeToEndTreeList(treeNodeList* lst, treeNodeListCell* tail);
pathTree findAllPossibleKnightPaths(chessPos* startingPosition);
void insertDataToEndTreeList(treeNodeList* lst, treeNode* node);
void freeMatrixPos(chessPosArray*** matrixPos);
treeNode* createTreeNode(chessPos position);
void makeEmptyTreeList(treeNodeList* lst);

// *** - q4
chessPosList* findKnightPathCoveringAllBoardHelper(treeNode* root, bool visited[BOARD][BOARD], bool* fullMatrix, chessPosList* lst);
chessPosList* findKnightPathCoveringAllBoard(pathTree* path_tree);
void removeDataFromEndList(chessPosList* lst);
bool isFullMatrix(bool visited[BOARD][BOARD]);

#endif