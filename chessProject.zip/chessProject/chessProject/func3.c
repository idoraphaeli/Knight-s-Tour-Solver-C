#include "chessProject.h"

pathTree findAllPossibleKnightPaths(chessPos* startingPosition) { // build tree with all possible positions
    pathTree tree;

    int i = startingPosition[0][0] - 'A';
    int j = startingPosition[0][1] - '1';
    startingPosition[0][1] = startingPosition[0][1] - '0';

    treeNode* root = createTreeNode(*startingPosition);

    bool visited[BOARD][BOARD] = { false }; // matrix of all steps that we already been
    visited[i][j] = true;

    chessPosArray*** matrixPos = validKnightMoves(); // all possible positions by function from task 1

    buildPathTree(root, visited, matrixPos); // rec function that build the tree

    freeMatrixPos(matrixPos);

    tree.root = root;

    return tree;
}

void freeMatrixPos(chessPosArray*** matrixPos) {
    for (int i = 0; i < BOARD; i++) {

        free(matrixPos[i]);
    }
    free(matrixPos);
}

void buildPathTree(treeNode* root, bool visited[][BOARD], chessPosArray*** matrixPos) {
    int i = root->position[0] - 'A';
    int j = root->position[1] - 1;
    bool check = true;

    for (int k = 0; k < matrixPos[i][j]->size; k++) {           // 
        int newI = matrixPos[i][j]->positions[k][0] - 'A';      //
        int newJ = matrixPos[i][j]->positions[k][1] - 1;        // check if we have been at all possible positions
        if (visited[newI][newJ] == false) {                     //
            check = false;                                      //
            break;
        }
    }
    if (check == true) {
        root = createTreeNode(root->position);
        return;
    }

    for (int k = 0; k < matrixPos[i][j]->size; k++) {
        int newI = matrixPos[i][j]->positions[k][0] - 'A';
        int newJ = matrixPos[i][j]->positions[k][1] - 1;

        if (visited[newI][newJ] == false) { // if we havent been at that position
            visited[newI][newJ] = true;

            treeNode* child = createTreeNode(matrixPos[i][j]->positions[k]);
            insertDataToEndTreeList(&(root->next_possible_positions), child);

            buildPathTree(child, visited, matrixPos);

            visited[newI][newJ] = false;
        }
    }
}

treeNode* createTreeNode(chessPos position) { // create tree node
    treeNode* node = (treeNode*)malloc(sizeof(treeNode));
    CheckAllocation(node);

    node->position[0] = position[0];
    node->position[1] = position[1];
    node->next_possible_positions.head = node->next_possible_positions.tail = NULL;

    return node;
}

void makeEmptyTreeList(treeNodeList* lst) { // make empty list
    lst->head = NULL;
    lst->tail = NULL;
}

void insertDataToEndTreeList(treeNodeList* lst, treeNode* node) // insert data to the end of a list
{
    treeNodeListCell* newTail;
    newTail = createNewTreeListNode(node, NULL);
    insertNodeToEndTreeList(lst, newTail);
}

treeNodeListCell* createNewTreeListNode(treeNode* node, treeNodeListCell* next) // creat new tree list node 
{
    treeNodeListCell* res;
    res = (treeNodeListCell*)malloc(sizeof(treeNodeListCell));
    CheckAllocation(res);

    res->node = node;
    res->next = next;

    return res;
}

void insertNodeToEndTreeList(treeNodeList* lst, treeNodeListCell* tail) { // insert the node to the end of the list
    if (lst->head == NULL) {
        lst->head = lst->tail = tail;
    }
    else {
        lst->tail->next = tail;
        lst->tail = tail;
    }
    tail->next = NULL;
}