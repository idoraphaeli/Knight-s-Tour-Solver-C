#include "chessProject.h"

chessPosList* findKnightPathCoveringAllBoard(pathTree* path_tree) {
    bool fullMatrix = false;
    chessPosList* lst = (chessPosList*)malloc(sizeof(chessPosList));
    makeEmptyList(lst);

    bool visited[BOARD][BOARD] = { false }; // matrix of all steps that we already been

    insertDataToEndList(lst, path_tree->root->position);
    lst = findKnightPathCoveringAllBoardHelper(path_tree->root, visited, &fullMatrix, lst);
    return lst;
}

chessPosList* findKnightPathCoveringAllBoardHelper(treeNode* root, bool visited[BOARD][BOARD], bool* fullMatrix, chessPosList* lst) {

    int i = root->position[0] - 'A';
    int j = root->position[1] - 1;
    visited[i][j] = true;

    if (isFullMatrix(visited) == true) {
        insertDataToEndList(lst, root->position);
        *fullMatrix = true;
        return lst;
    }

    if (*fullMatrix == true)
        return lst;

    treeNodeListCell* curr = root->next_possible_positions.head;

    while (curr != NULL) {
        int newI = curr->node->position[0] - 'A';
        int newJ = curr->node->position[1] - 1;

        if (visited[newI][newJ] == false) { // if we havent been at that position
            insertDataToEndList(lst, curr->node->position);
            findKnightPathCoveringAllBoardHelper(curr->node, visited, fullMatrix, lst);

            if (!*fullMatrix)
                removeDataFromEndList(lst);
            else
                return lst;
        }

        curr = curr->next;
    }

    visited[i][j] = false;
    return NULL;
}

void removeDataFromEndList(chessPosList* lst) {

    chessPosCell* curr = lst->head;
    if (lst->head->next == NULL) {
        makeEmptyList(lst);
    }

    while (curr->next != lst->tail) {
        curr = curr->next;
    }

    chessPosCell* temp = curr->next;
    lst->tail = curr;
    curr->next = NULL;
    free(temp);

}

bool isFullMatrix(bool visited[BOARD][BOARD]) {
    for (int i = 0; i < BOARD; i++) {
        for (int j = 0; j < BOARD; j++) {
            if (!visited[i][j]) {
                return false;
            }
        }
    }
    return true;
}