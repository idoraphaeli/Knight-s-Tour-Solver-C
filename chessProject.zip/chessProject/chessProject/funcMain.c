#include "chessProject.h"

void isValid(chessPos userPos) {
    char lett = userPos[0];
    char dig = userPos[1];

    if ((lett >= 'A' && lett < 'A' + BOARD) && (dig >= '1' && dig < '1' + BOARD))
        return;
    else {
        printf("Invalid input");
        exit(1);
    }
}

void freeTree(pathTree* tree) {
    freeTreeHelper(tree->root);
}

void freeTreeHelper(treeNode* root) {

    if (root->next_possible_positions.head == NULL && root->next_possible_positions.tail == NULL) {
        free(root);
        return;
    }

    treeNodeListCell* curr = root->next_possible_positions.head;
    treeNodeListCell* tmp = curr;

    while (curr != NULL) {
        freeTreeHelper(curr->node);
        tmp = curr;
        curr = curr->next;
        root->next_possible_positions.head = curr;
        free(tmp);
    }

    return;
}

void freeMatrix(int** matrix) {

    for (int i = 0; i < BOARD; i++) {

        free(matrix[i]);
    }
    free(matrix);
}
