#include "chessProject.h"

chessPosArray*** validKnightMoves() { // create an array of all steps the knight can make from posistion on board
    int i = 0, j = 0;

    chessPosArray*** res = (chessPosArray***)malloc(BOARD * sizeof(chessPosArray**));
    CheckAllocation(&res);

    for (i = 0; i < BOARD; i++) {
        res[i] = (chessPosArray**)malloc(BOARD * sizeof(chessPosArray*));
        CheckAllocation(res[i]);

        for (j = 0; j < BOARD; j++) {
            res[i][j] = (chessPosArray*)malloc(sizeof(chessPosArray));
            CheckAllocation(res[i][j]);
        }
    }

    insertSizeAndPos(res);

    return res;
}

void insertSizeAndPos(chessPosArray*** res) {
    int i = 0, j = 0;
    int size = 0;

    for (i = 0; i < BOARD; i++)
    {
        for (j = 0; j < BOARD; j++)
        {
            size = findSizeKnight(i, j);
            (res[i][j])->size = size;
            (res[i][j])->positions = findPosKnight(i, j, size);
        }
    }
}

void CheckAllocation(void* ptr) //check the success of the malloc
{
    if (ptr == NULL) {
        exit(EXIT);
    }
}

int findSizeKnight(int i, int j) { // find how many steps the knight can do

    int counter = 0;

    if (inMatrix(i + 2, j + 1)) {
        counter++;
    }
    if (inMatrix(i + 1, j + 2)) {
        counter++;
    }
    if (inMatrix(i - 1, j + 2)) {
        counter++;
    }
    if (inMatrix(i - 2, j + 1)) {
        counter++;
    }
    if (inMatrix(i - 2, j - 1)) {
        counter++;
    }
    if (inMatrix(i - 1, j - 2)) {
        counter++;
    }
    if (inMatrix(i + 1, j - 2)) {
        counter++;
    }
    if (inMatrix(i + 2, j - 1)) {
        counter++;
    }

    return counter;


}

chessPos* findPosKnight(int i, int j, int size) { // find the places the knight can get

    int counter = 0;

    chessPos* pos = (chessPos*)malloc(size * sizeof(chessPos));

    if (inMatrix(i - 2, j + 1)) {
        pos[counter][0] = numToChar(i - 2);
        pos[counter][1] = j + 1 + 1;
        counter++;
    }
    if (inMatrix(i - 1, j + 2)) {
        pos[counter][0] = numToChar(i - 1);
        pos[counter][1] = j + 2 + 1;
        counter++;
    }
    if (inMatrix(i + 1, j + 2)) {
        pos[counter][0] = numToChar(i + 1);
        pos[counter][1] = j + 2 + 1;
        counter++;
    }
    if (inMatrix(i + 2, j + 1)) {
        pos[counter][0] = numToChar(i + 2);
        pos[counter][1] = j + 1 + 1;
        counter++;
    }
    if (inMatrix(i + 2, j - 1)) {
        pos[counter][0] = numToChar(i + 2);
        pos[counter][1] = j - 1 + 1;
        counter++;
    }
    if (inMatrix(i + 1, j - 2)) {
        pos[counter][0] = numToChar(i + 1);
        pos[counter][1] = j - 2 + 1;
        counter++;
    }
    if (inMatrix(i - 1, j - 2)) {
        pos[counter][0] = numToChar(i - 1);
        pos[counter][1] = j - 2 + 1;
        counter++;
    }
    if (inMatrix(i - 2, j - 1)) {
        pos[counter][0] = numToChar(i - 2);
        pos[counter][1] = j - 1 + 1;
        counter++;
    }

    return pos;
}

bool inMatrix(int i, int j) { // check if the move is on the board
    if ((i >= 0 && i <= BOARD - 1) && (j >= 0 && j <= BOARD - 1))
        return true;
    else
        return false;
}

char numToChar(int i) {

    return 'A' + i;
}
