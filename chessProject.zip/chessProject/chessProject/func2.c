#include "chessProject.h"

void display(chessPosList* lst) { // adjust the list and build matrix from the list information
    chessPosList* res;
    res = adjustList(lst);
    int** board = NULL;
    board = buildChessBoardFromList(res);
    printMatrix(&board);
    freeMatrix(board);
}

void printMatrix(int*** matrix) { // print the matrix
    int p = 0, k = 0;
    int i = 0;

    printf("   ");

    for (i = 0; i < BOARD; i++)
    {
        if (1 + k <= 8) {
            printf("%d  ", 1 + k);
            k++;
        }
        else if (1 + k == 9) {
            printf("%d ", 1 + k);
            k++;
        }
        else if (1 + k >= 10) {
            printf("%2d ", 1 + k);
            k++;
        }
    }

    printf("\n");
    k = 0;

    for (i = 0; i < BOARD; i++)
    {
        printf("%c", 'A' + k);
        k++;
        for (int j = 0; j < BOARD; j++)
        {
            printf("|");
            printf("%2d", (*matrix)[i][j]);
        }

        printf("|");
        printf("\n");
    }
}

int** buildChessBoardFromList(chessPosList* lst) { // build matrix by the lisr information

    int** board = (int**)malloc(BOARD * sizeof(int*));
    for (int i = 0; i < BOARD; i++) {
        board[i] = (int*)malloc(BOARD * sizeof(int));

        for (int j = 0; j < BOARD; j++) {
            board[i][j] = 0;
        }
    }

    int index = 1;
    chessPosCell* curr = lst->head;
    int i = 0, j = 0;

    while (curr != NULL) {
        i = charToNum(curr->position[0]);
        j = (curr->position[1]) - 1;  ///// deleted

        board[i][j] = index;
        index++;
        curr = curr->next;
    }

    return board;
}

chessPosList* adjustList(chessPosList* lst) { // remove all position that showed twice at the list
    chessPosList* res = (chessPosList*)malloc(sizeof(chessPosList));
    chessPosCell* currOrigin = lst->head;
    makeEmptyList(res);

    insertDataToEndList(res, lst->head->position);
    chessPosCell* currNew = res->head;
    bool exist = false;

    while (currOrigin != NULL) {
        exist = false;
        currNew = res->head;

        while (currNew != NULL) {

            if (currOrigin->position[0] == currNew->position[0] && currOrigin->position[1] == currNew->position[1]) {
                exist = true;
                break;
            }
            currNew = currNew->next;
        }
        if (exist == false)
            insertDataToEndList(res, currOrigin->position);

        currOrigin = currOrigin->next;
    }

    return res;
}

void insertDataToEndList(chessPosList* lst, chessPos data) // insert data to the end of a list
{
    chessPosCell* newTail;
    newTail = createNewListNode(data, NULL);
    insertNodeToEndList(lst, newTail);
}

chessPosCell* createNewListNode(chessPos data, chessPosCell* next) // creat new node 
{
    chessPosCell* res = NULL;
    res = (chessPosCell*)malloc(sizeof(chessPosCell));
    CheckAllocation(res);

    res->position[0] = data[0];
    res->position[1] = data[1];

    res->next = next;

    return res;
}

void insertNodeToEndList(chessPosList* lst, chessPosCell* tail) // insert node to end list
{
    if (isEmptyList(lst) == true) {
        lst->head = lst->tail = tail;
    }
    else {
        lst->tail->next = tail;
        lst->tail = tail;
    }
    tail->next = NULL;
}

bool isEmptyList(chessPosList* lst) // check if the list is empty
{
    if (lst->head == NULL)
        return true;
    else
        return false;
}

void makeEmptyList(chessPosList* lst) // make list empty by NULL
{
    lst->head = NULL;
    lst->tail = NULL;
}

char charToNum(char ch) {

    return ch - 'A';
}